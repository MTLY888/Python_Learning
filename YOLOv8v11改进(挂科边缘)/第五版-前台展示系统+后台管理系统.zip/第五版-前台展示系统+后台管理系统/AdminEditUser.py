# -*- coding: utf-8 -*-
"""
@Auth ：挂科边缘
@File ：AdminAddUser.py
@IDE ：PyCharm
@Motto :学习新思想，争做新青年
"""
import os
import re
import sys
import datetime

from PySide6.QtCore import Signal

from utils.message import DialogOver

sys.path.append('ui/admin')
from mysql.dataDB import *
from PySide6.QtGui import QIcon, Qt, QPalette, QBrush, QPixmap, QGuiApplication, QColor
from PySide6.QtWidgets import QMainWindow, QMessageBox, QApplication, QFileDialog
from ui.admin.admin_edit_dialog import Ui_edit
from utils.avatar import save_avatar_file, upload_avatar, set_circular_avatar


class EditUserWindow(QMainWindow, Ui_edit):
    user_updated = Signal()
    def __init__(self, user_id, username, nickname, avatar_filename, register_time,parent=None):
        super(EditUserWindow, self).__init__(parent)
        self.setupUi(self)  # 初始化界面

        # 保存用户信息
        self.user_id = user_id
        self.username = username
        self.nickname = nickname
        self.avatar_filename = avatar_filename
        self.set_avatar(avatar_filename)
        self.register_time = register_time
        self.label_edituser_avatar.mousePressEvent = self.upload_avatar
        self.upload_avatar_path = None  # 初始化头像文件路径
        self.init_ui()
        self.save_btn.clicked.connect(self.handleSubmit)
        self.cancel_btn.clicked.connect(self.close)



    def init_ui(self):
        # 将用户信息显示在对应的控件中
        self.edit_username.setText(self.username)
        self.edit_nickname.setText(self.nickname)

        register_time_str = self.register_time.strftime("%Y-%m-%d")  # 格式化时间为字
        self.user_register_time.setText(register_time_str)

    def upload_avatar(self, event):
        image_path = upload_avatar(self.label_edituser_avatar, circular=True)
        if image_path:
            self.upload_avatar_path = image_path  # 上传路径

    def set_avatar(self, avatar_filename):
        """设置头像并更新显示"""
        if avatar_filename:
            # 加载头像并设置到 QLabel
            avatar_path = os.path.join("user_avatars", avatar_filename)
            pixmap = QPixmap(avatar_path)
            if not pixmap.isNull():
                self.label_edituser_avatar.setPixmap(pixmap)
                set_circular_avatar(self.label_edituser_avatar)
        else:
            print("没有头像路径")



    def handleSubmit(self):
        """提交修改并更新数据库"""
        new_nickname = self.edit_nickname.text().strip()  # 获取昵称
        new_username  = self.edit_username.text().strip()  # 获取账号

        is_admin = 0

        if not self.upload_avatar_path and self.nickname == new_nickname and self.username == new_username:
            DialogOver(parent=self, text="未修改任何信息！", title="提交失败", flags="warning")
            return

        # 检查昵称和账号是否为空
        if len(new_username) == 0 or len(new_nickname) == 0:
            DialogOver(parent=self, text="昵称、账号不能为空", title="错误", flags="warning")
            return

        # 检查账号是否为有效的手机号
        ret = re.match(r"1[356789]\d{9}", new_username)
        if ret is None or len(new_username) != 11:
            DialogOver(parent=self, text="手机号错误", title="错误", flags="warning")
            return

        # 如果用户名被修改，检查数据库中是否存在重复的账号
        if new_username != self.username:
            sql_check_username = "SELECT * FROM user WHERE username = '%s'" % new_username
            result = selectDB(sql_check_username)
            if result:
                DialogOver(parent=self, text="账号已存在，请使用其他账号！", title="错误", flags="warning")
                return


        if not self.upload_avatar_path:
            avatar_filename = self.avatar_filename
        else:
            avatar_filename = save_avatar_file(self.upload_avatar_path)


        sql = "UPDATE user SET nick_name= '%s', avatar='%s' ,username='%s',is_admin='%s' WHERE id='%s'" % (new_nickname, avatar_filename,new_username,is_admin,self.user_id)
        result = insertDB(sql)
        if result:
            DialogOver(parent=self, text="修改已保存！", title="提交成功", flags="success")
            self.user_updated.emit()
            self.hide()
        else:
            DialogOver(parent=self, text="保存失败，请稍后再试！", title="提交失败", flags="danger")

