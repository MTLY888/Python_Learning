# -*- coding: utf-8 -*-
"""
@Auth ：挂科边缘
@File ：AdminAddUser.py
@IDE ：PyCharm
@Motto :学习新思想，争做新青年
"""
import re
import sys
import datetime

from PySide6.QtCore import Signal

from utils.message import DialogOver

sys.path.append('ui/admin')
from mysql.dataDB import *
from PySide6.QtGui import QIcon, Qt, QPalette, QBrush, QPixmap, QGuiApplication, QColor
from PySide6.QtWidgets import QMainWindow, QMessageBox, QApplication, QFileDialog
from ui.admin.admin_add_dialog import Ui_add
from utils.avatar import save_avatar_file, upload_avatar

class AddUserWindow(QMainWindow, Ui_add):
    add_user_updated = Signal()
    def __init__(self, parent=None):
        super(AddUserWindow, self).__init__(parent)
        self.setupUi(self)  # 初始化界面
        self.avatar_file_path = None  # 初始化头像文件路径
        self.label_adduser_avatar.mousePressEvent = self.upload_avatar
        self.save_btn.clicked.connect(self.save_data)
        self.cancel_btn.clicked.connect(self.close)




    def upload_avatar(self, event):
        """处理点击头像时上传头像"""
        # 上传头像并显示为带边框的头像
        image_path = upload_avatar(self.label_adduser_avatar, circular=False, border_width=30, border_color=QColor('#ffffff'))
        if image_path:
            self.avatar_file_path = image_path  # 保存文件路径

    def save_data(self):
        nick_nema = self.add_nickname.text().strip()
        username = self.add_username.text().strip()
        password = self.add_password.text().strip()
        is_admin = 0


        # 匹配手机号
        ret = re.match("1[356789]\d{9}", username)


        le = len(username)

        if len(username) == 0 or len(password) == 0  or len(nick_nema) == 0:
            DialogOver(parent=self, text="昵称、账号、密码不能为空", title="错误", flags="warning")
            return
        # 手机号不匹配
        if ret is None or le != 11:
            DialogOver(parent=self, text="手机号错误", title="错误", flags="warning")
            return
        # 匹配密码包含数字，字母，特殊字符
        """  分开来注释一下：
                ^ 匹配一行的开头位置
                (?![0-9]+$)预测该位置后面不全是数字
                (?![a-zA-Z]+$)预测该位置后面不全是字母
                [0 - 9A - Za - z]{8, 16}由8 - 16位数字或这字母组成  
                $ 匹配行结尾位置 """
        ret_psd = re.match(
            "^(?![A-Za-z]+$)(?![A-Z0-9]+$)(?![a-z0-9]+$)(?![a-z\W]+$)(?![A-Z\W]+$)(?![0-9\W]+$)[a-zA-Z0-9\W]{6,16}$",
            password)
        if not ret_psd:
            DialogOver(parent=self, text="密码不符合要求，必须包含字母、数字、特殊字符", title="错误", flags="warning")
            return

        sql = "select * from user where username = '%s'" % username
        result = selectDB(sql)
        if len(result) != 0:
            DialogOver(parent=self, text="该账号已存在，请重新注册", title="错误", flags="warning")
            return
        # 检查头像是否上传
        if self.avatar_file_path is None:
            DialogOver(parent=self, text="请上传头像", title="错误", flags="warning")
            return

        else:
            register_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            avatar_filename = save_avatar_file(self.avatar_file_path)
            sql2 = "insert into user(username,password,nick_name, avatar,register_time,is_admin) values ('%s','%s','%s','%s','%s','%s')" % (username, password,nick_nema,avatar_filename,register_time,is_admin)
            insertDB(sql2)

            DialogOver(parent=self, text="恭喜您添加成功", title="成功", flags="success")
            self.add_user_updated.emit()
            self.hide()










if __name__ == "__main__":
    QGuiApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.Ceil)
    app = QApplication([])
    SI.AddWindow = AddUserWindow()
    SI.AddWindow.show()
    sys.exit(app.exec())
