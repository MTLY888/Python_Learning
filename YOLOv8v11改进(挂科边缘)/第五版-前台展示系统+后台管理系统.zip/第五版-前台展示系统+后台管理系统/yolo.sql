/*
 Navicat Premium Data Transfer

 Source Server         : python
 Source Server Type    : MySQL
 Source Server Version : 80013
 Source Host           : localhost:3306
 Source Schema         : yolo

 Target Server Type    : MySQL
 Target Server Version : 80013
 File Encoding         : 65001

 Date: 11/02/2025 15:44:17
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `password` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `nick_name` varchar(12) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `avatar` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `register_time` datetime(6) NULL DEFAULT NULL,
  `is_admin` int(1) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 65 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (48, 'admin', '1', '管理员', '20250209042953_挂科.jpg', '2025-02-09 12:52:05.000000', 1);
INSERT INTO `user` VALUES (56, '16755689561', '112123@d', '11', '20250211005347_kk.jpg', '2025-02-11 00:53:47.000000', 0);
INSERT INTO `user` VALUES (63, '16755689564', 'jksdfklsa-ll99', '发财', '20250211010654_挂科.jpg', '2025-02-11 01:06:54.000000', 0);
INSERT INTO `user` VALUES (64, '16755689569', 'dffdf--ll00', 'csdn挂科边缘', '20250211010828_挂科.jpg', '2025-02-11 01:08:28.000000', 0);

SET FOREIGN_KEY_CHECKS = 1;
